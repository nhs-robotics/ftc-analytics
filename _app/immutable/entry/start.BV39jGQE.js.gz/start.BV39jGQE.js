import{a as t}from"../chunks/entry.BCJtBRnR.js";export{t as start};
