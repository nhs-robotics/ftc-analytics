import{v as a}from"./runtime.BGR35c18.js";a();
