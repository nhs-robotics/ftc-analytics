import{a as t}from"../chunks/entry.B3aDG5ke.js";export{t as start};
